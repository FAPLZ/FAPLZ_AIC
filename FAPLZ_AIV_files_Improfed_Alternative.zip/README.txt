Important:

That the AIV files work correctly, you have to rename it.

For example The File: "wolf1_improfed_alt1.aiv" have to rename to "wolf1.aiv".

You can choose a name from 1 to 8 (for example; "wolf1.aiv", "wolf2.aiv", ... , "wolf8.aiv" ).

Generally the Name for the AIV file is the Name of the Lord attached with a number (from 1 to 8).

